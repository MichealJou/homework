<?php
/**
 * Created by PhpStorm.
 * User: zhouping
 * Date: 16/1/29
 * Time: 上午12:29
 */
namespace Home\Model;
use Think\Model;
class  AdminModel extends Model
{

  protected  $tablePrefix = "t_";
  protected  $tableName = "admin";
}


?>