<?php
/**
 * Created by PhpStorm.
 * User: zhouping
 * Date: 16/2/1
 * Time: 上午7:54
 */

namespace Admin\Controller;


use Think\Controller;

class HomeController extends CommonController
{
       public function test(){
           echo 'kkkkk';
       }
}
?>