<?php
/**
 * Created by PhpStorm.
 * User: zhouping
 * Date: 16/1/31
 * Time: 下午11:06
 */

namespace Admin\Controller;


use Think\Controller;

class IndexController extends CommonController
{

  public function index(){
      $this->display();
  }
}
?>