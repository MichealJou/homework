<?php
/**
 * Created by PhpStorm.
 * User: zhouping
 * Date: 16/2/3
 * Time: 下午9:57
 */
namespace Admin\Model;
use Think\Model;
class AdminModel extends Model{

    protected  $tablePrefix = "t_";
    protected  $tableName = "admin";

}


?>