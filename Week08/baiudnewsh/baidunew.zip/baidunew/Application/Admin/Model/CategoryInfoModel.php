<?php
/**
 * Created by PhpStorm.
 * User: zhouping
 * Date: 16/2/21
 * Time: 下午4:17
 */

namespace Admin\Model;


use Think\Model;

class CategoryInfoModel extends Model
{


}